#!/usr/bin/python3

import os

os.system("pip3 install selenium &")
os.system("pip3 install bs4")
os.system("pip3 install lxml")
os.system("pip3 install folium")
os.system("apt-get update &")
os.system("apt install chromium-chromedriver &")
os.system("dpkg --configure -a &")
os.system("cp /usr/lib/chromium-browser /usr/bin &")
